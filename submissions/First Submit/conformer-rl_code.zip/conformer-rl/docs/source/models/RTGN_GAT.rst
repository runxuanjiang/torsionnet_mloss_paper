.. automodule:: conformer_rl.models.RTGN_GAT
    :members: