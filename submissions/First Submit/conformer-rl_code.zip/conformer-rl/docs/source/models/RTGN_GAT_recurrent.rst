.. automodule:: conformer_rl.models.RTGN_GAT_recurrent
    :members: