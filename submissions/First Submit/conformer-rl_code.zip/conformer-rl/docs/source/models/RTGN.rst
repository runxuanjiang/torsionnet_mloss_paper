.. automodule:: conformer_rl.models.RTGN
    :members: