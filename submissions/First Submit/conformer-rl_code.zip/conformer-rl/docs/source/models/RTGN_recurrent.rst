.. automodule:: conformer_rl.models.RTGN_recurrent
    :members: