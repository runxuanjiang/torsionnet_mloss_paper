.. automodule:: conformer_rl.agents.A2C.A2C_agent
    :members:
    :show-inheritance:
    :inherited-members: