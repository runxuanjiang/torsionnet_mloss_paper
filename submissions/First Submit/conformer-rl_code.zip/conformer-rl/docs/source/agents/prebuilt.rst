Pre-built agents
================

.. toctree::
   :maxdepth: 2
   :caption: Pre-built agents

   A2C/A2C_agent
   A2C/A2C_recurrent_agent
   PPO/PPO_agent
   PPO/PPO_recurrent_agent