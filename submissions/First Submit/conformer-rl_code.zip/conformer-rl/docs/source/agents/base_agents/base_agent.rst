.. automodule:: conformer_rl.agents.base_agent
    :members:
    :private-members: