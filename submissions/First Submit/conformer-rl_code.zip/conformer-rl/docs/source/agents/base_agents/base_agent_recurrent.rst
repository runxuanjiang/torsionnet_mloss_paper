.. automodule:: conformer_rl.agents.base_agent_recurrent
    :members:
    :private-members:
    :show-inheritance:
    :inherited-members: