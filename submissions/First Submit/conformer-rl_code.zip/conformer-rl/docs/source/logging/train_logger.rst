.. automodule:: conformer_rl.logging.train_logger
    :members:
    :private-members: