.. automodule:: conformer_rl.config.mol_config
    :members:
    :private-members: