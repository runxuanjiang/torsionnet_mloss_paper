Molecule Generation Scripts
===========================

.. toctree::
    :maxdepth: 2
    :caption: Generation Scripts

    generate_branched_alkane
    generate_lignin
    generate_xor_gate