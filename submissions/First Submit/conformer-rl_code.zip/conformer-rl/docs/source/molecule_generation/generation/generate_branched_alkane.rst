.. automodule:: conformer_rl.molecule_generation.generation.generate_branched_alkane
    :members:
    :private-members: