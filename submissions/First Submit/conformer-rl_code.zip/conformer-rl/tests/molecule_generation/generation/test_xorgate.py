from conformer_rl.molecule_generation.generation.generate_xor_gate import generate_xor_gate

# additional testing done in jupyter notebook
def test_xorgate(mocker):
    mol = generate_xor_gate()


    
